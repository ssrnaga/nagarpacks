#ifndef _debias_H
#define _debias_H


#include <RcppArmadillo.h>
using namespace Rcpp ;

RcppExport SEXP MLEw2p (SEXP arg1, SEXP arg2, SEXP arg3);
RcppExport SEXP MLEln2p (SEXP arg1, SEXP arg2, SEXP arg3, SEXP arg4);



#endif
